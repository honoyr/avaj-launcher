import weather.WeatherProvider;

public class AirCraftimulation {

    public static void main(String[] args){

        WeatherProvider weatherProvider = new WeatherProvider();

        WeatherTower weatherTower = new WeatherTower();

        weatherTower.setCycle(25);

//        weatherTower.getWeather(654, 33, 20);

//        AircraftFactory aircraftFactory = new AircraftFactory();

//        Flyable flyable = new Flyable();

//        aircraftFactory.newAircraft("Helicopter", "H1", 654, 33, 20);

//        Aircraft Helicopter =

//        weatherTower.register(AircraftFactory.newAircraft("Helicopter", "H1", 434, 35, 20));
        weatherTower.register(AircraftFactory.newAircraft("Baloon", "B1", 654, 33, 56));
//        weatherTower.register(AircraftFactory.newAircraft("JetPlane", "J1", 954, 83, 40));
//        weatherTower.register(AircraftFactory.newAircraft("Helicopter", "H1", 654, 33, 20));

        weatherTower.changeWeather();
    }
}
