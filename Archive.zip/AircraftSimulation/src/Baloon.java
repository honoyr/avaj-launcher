public class Baloon extends Aircraft implements Flyable {

    public Baloon(String name, Coordinates coordinates) {
        super(name, coordinates);
    }

    @Override
    public void updateConditions() {

        String weather = weatherTower.getWeather(coordinates);
//        Class.getSimpleName()
//        if (coordinates.getHeight() <= 0)
//        {
//            weatherTower.unregister(this);
//            System.out.println(this.getClass().getName() + "#" + getName()
//                    + "(" + getId() + "):"
//                    + "Good weather for fly. Let's enjoy the good weather and take some pics.");
//        }

        switch(weather){
            case "SUM":
            {
                coordinates.setLongitude(coordinates.getLatitude() + 2);
                coordinates.setHeight(coordinates.getHeight() + 4);
                System.out.println(this.getClass().getName() + "#" + getName()
                        + "(" + getId() + "):"
                        + "Good weather for fly. Let's enjoy the good weather and take some pics.");
                break ;
            }
            case "RAIN" {
                coordinates.setHeight(coordinates.getHeight() - 5);
                System.out.println(this.getClass().getName() + "#" + getName()
                        + "(" + getId() + "):"
                        + "Damn you rain! You messed up my baloon.");
                break ;
            }
            case "FOG": {
                coordinates.setHeight(coordinates.getHeight() - 3);
                System.out.println(this.getClass().getName() + "#" + getName()
                        + "(" + getId() + "):"
                        + "OMG! I'm like a big cherry in the sky. I don't see any");
                break ;
            }
            case "SNOW": {
                coordinates.setHeight(coordinates.getHeight() - 15);
                System.out.print(getInfo());
                System.out.println("It's snowing. We're  gonna crash.");
                break ;
            }
        }
        if (coordinates.getHeight() == 0)
        {
            System.out.print(getInfo());
            land();
            weatherTower.unregister(this);
        }
    }
//
//    @Override
//    public void registerTower(WeatherTower weatherTower) {
//        weatherTower.register(this);
//    }

    public void land(){
        System.out.println("Landing. Coordinates: Height = " + coordinates.getHeight()
                + " longitude = " + coordinates.getLongitude()
                + " Latitude = " + coordinates.getLatitude());
    }

    public String getInfo(){
        String messege = Class.getSimpleName() + "#" + getName() + "(" + getId() + "):";
        return (messege);
    }

}
