import java.util.ArrayList;

abstract public class Tower implements Flyable{
    private ArrayList<Flyable> observers = new ArrayList<>();

    public void register(Flyable flyable){

        observers.add(flyable);

    }
    public void unregister(Flyable flyable){

        System.out.println(this.getClass().getName() + " says: "
                + observers.get(flyable).getInfo()
                +  "unregistered from weather tower.");
        observers.remove(flyable);
    }
    protected void conditionsChanged(){
        for (Flyable check : observers){
            System.out.println(check.getInfo);
            check.updateConditions();
        }
    }

}
