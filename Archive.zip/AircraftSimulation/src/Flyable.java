

abstract public class Flyable {
    public abstract void updateConditions();
    public abstract void registerTower(WeatherTower weatherTower);
    public abstract String getInfo();
}
