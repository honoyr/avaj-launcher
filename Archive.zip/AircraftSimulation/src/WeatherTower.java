import weather.WeatherProvider;

import java.util.ArrayList;

public class WeatherTower extends Tower {

    private int cycle;

    public WeatherTower() {
    }

    public WeatherTower(int cycle) {
        this.cycle = cycle;
    }

    public String getWeather(Coordinates coordinates){
        WeatherProvider.getProvider().getCurrentWeather(coordinates);

    }

    void changeWeather(){
        for (int i = 0; i < cycle; i++){
            conditionsChanged();
        }
    }

    public void setCycle(int cycle) {
        this.cycle = cycle;
    }
}
